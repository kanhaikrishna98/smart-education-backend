const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { createPlan } = require("./lib/planner");

const publicDirectory = path.join(__dirname, "public");
const dataDirectory = path.join(__dirname, "data");
const plansFile = path.join(dataDirectory, "plans.json");
const PORT = Number(process.env.PORT) || 3000;
const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8"
};

function sendJson(response, statusCode, body) {
  response.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  response.end(JSON.stringify(body));
}

function readBody(request) {
  return new Promise((resolve, reject) => {
    let raw = "";
    request.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 100_000) {
        reject(new Error("Request is too large."));
        request.destroy();
      }
    });
    request.on("end", () => {
      try { resolve(raw ? JSON.parse(raw) : {}); }
      catch { reject(new Error("Request body must be valid JSON.")); }
    });
    request.on("error", reject);
  });
}

function loadPlans() {
  try { return JSON.parse(fs.readFileSync(plansFile, "utf8")); }
  catch { return []; }
}

function savePlan(plan) {
  fs.mkdirSync(dataDirectory, { recursive: true });
  const plans = loadPlans().slice(0, 9);
  const record = { id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`, ...plan };
  fs.writeFileSync(plansFile, JSON.stringify([record, ...plans], null, 2));
  return record;
}

function serveStatic(request, response) {
  const requestPath = request.url === "/" ? "/index.html" : request.url.split("?")[0];
  const safePath = path.normalize(requestPath).replace(/^([.]{2}[\\/])+/, "");
  const filePath = path.join(publicDirectory, safePath);
  if (!filePath.startsWith(publicDirectory)) return sendJson(response, 403, { error: "Forbidden" });
  fs.readFile(filePath, (error, content) => {
    if (error) return sendJson(response, 404, { error: "Not found" });
    response.writeHead(200, { "Content-Type": MIME_TYPES[path.extname(filePath)] || "application/octet-stream" });
    response.end(content);
  });
}

const server = http.createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/api/health") return sendJson(response, 200, { status: "ok" });
    if (request.method === "GET" && request.url === "/api/plans") return sendJson(response, 200, { plans: loadPlans() });
    if (request.method === "POST" && request.url === "/api/analyze") {
      return sendJson(response, 200, { plan: createPlan(await readBody(request)) });
    }
    if (request.method === "POST" && request.url === "/api/plans") {
      const plan = createPlan(await readBody(request));
      return sendJson(response, 201, { plan: savePlan(plan) });
    }
    if (request.method === "GET") return serveStatic(request, response);
    return sendJson(response, 405, { error: "Method not allowed" });
  } catch (error) {
    return sendJson(response, 400, { error: error.message || "Unable to create a plan." });
  }
});

server.listen(PORT, () => console.log(`Student Progress AI Tracker is running at http://localhost:${PORT}`));
