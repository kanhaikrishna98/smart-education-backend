const test = require("node:test");
const assert = require("node:assert/strict");
const { createPlan, linearTrend } = require("../lib/planner");

const availability = { mon: 90, tue: 90, wed: 60, thu: 90, fri: 60, sat: 120, sun: 90 };
const subjects = [
  { name: "Mathematics", score: 52, history: [61, 57, 52] },
  { name: "Science", score: 68, history: [65, 66, 68] },
  { name: "English", score: 84, history: [78, 81, 84] },
  { name: "Social Studies", score: 61, history: [68, 64, 61] }
];

test("linear trend identifies improving and declining histories", () => {
  assert.ok(linearTrend([50, 60, 70]) > 0);
  assert.ok(linearTrend([70, 60, 50]) < 0);
});

test("plan emphasizes the weakest declining subject and schedules available time", () => {
  const plan = createPlan({ subjects, availability });
  assert.equal(plan.subjects[0].name, "Mathematics");
  assert.equal(plan.subjects[0].tier.key, "priority");
  assert.equal(plan.schedule.totalMinutes, 600);
  assert.equal(plan.schedule.days.length, 7);
  assert.equal(plan.schedule.days.flatMap((day) => day.blocks).reduce((sum, block) => sum + block.duration, 0), 600);
  assert.ok(plan.schedule.allocations[0].targetMinutes > plan.schedule.allocations.at(-1).targetMinutes);
});

test("invalid input is rejected", () => {
  assert.throws(() => createPlan({ subjects: [{ name: "Math", score: 80 }], availability }), /2 and 8 subjects/);
  assert.throws(() => createPlan({ subjects: [{ name: "Math", score: 101 }, { name: "English", score: 70 }], availability }), /between 0 and 100/);
});
