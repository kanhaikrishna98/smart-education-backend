const DAYS = [
  ["mon", "Mon"], ["tue", "Tue"], ["wed", "Wed"], ["thu", "Thu"],
  ["fri", "Fri"], ["sat", "Sat"], ["sun", "Sun"]
];

const SAMPLE_PROFILE = {
  subjects: [
    { name: "Mathematics", score: 52, history: "61, 57" },
    { name: "Science", score: 68, history: "65, 66" },
    { name: "English", score: 84, history: "78, 81" },
    { name: "Social Studies", score: 61, history: "68, 64" }
  ],
  availability: { mon: 90, tue: 90, wed: 60, thu: 90, fri: 60, sat: 120, sun: 90 },
  startTime: "17:00"
};

const state = { profile: structuredClone(SAMPLE_PROFILE), plan: null };
const $ = (selector) => document.querySelector(selector);
const subjectFields = $("#subject-fields");
const availabilityFields = $("#availability-fields");
const toast = $("#toast");
let toastTimer;

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  })[character]);
}

function formatMinutes(minutes) {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return hours ? `${hours}h${mins ? ` ${mins}m` : ""}` : `${mins}m`;
}

function initials(name) {
  return name.split(/\s+/).map((word) => word[0]).slice(0, 2).join("").toUpperCase();
}

function parseTime(value) {
  const [hours, minutes] = String(value).split(":").map(Number);
  return (Number.isFinite(hours) ? hours : 17) * 60 + (Number.isFinite(minutes) ? minutes : 0);
}

function renderSubjectFields(subjects) {
  subjectFields.innerHTML = subjects.map((subject, index) => `
    <div class="subject-row" data-subject-index="${index}">
      <input name="subject" aria-label="Subject ${index + 1} name" maxlength="50" value="${escapeHtml(subject.name)}" placeholder="Subject name" required />
      <input name="score" aria-label="${escapeHtml(subject.name || `Subject ${index + 1}`)} latest score" type="number" min="0" max="100" value="${escapeHtml(subject.score)}" placeholder="0–100" required />
      <input name="history" aria-label="${escapeHtml(subject.name || `Subject ${index + 1}`)} earlier scores" value="${escapeHtml(subject.history)}" placeholder="e.g. 58, 63" />
      <button class="remove-subject" type="button" aria-label="Remove ${escapeHtml(subject.name || `subject ${index + 1}`)}" ${subjects.length <= 2 ? "disabled" : ""}>×</button>
    </div>
  `).join("");
}

function renderAvailability(availability) {
  availabilityFields.innerHTML = DAYS.map(([id, label]) => `
    <div class="day-field">
      <label for="availability-${id}">${label}</label>
      <div class="day-input-wrap"><input id="availability-${id}" name="${id}" type="number" min="0" max="240" value="${escapeHtml(availability[id])}" aria-label="${label} study minutes" /><span>min</span></div>
    </div>
  `).join("");
}

function populateProfile(profile) {
  renderSubjectFields(profile.subjects);
  renderAvailability(profile.availability);
  $("#start-time").value = profile.startTime;
}

function getProfileFromForm() {
  const rows = [...subjectFields.querySelectorAll(".subject-row")];
  const subjects = rows.map((row) => {
    const name = row.querySelector('[name="subject"]').value.trim();
    const score = Number(row.querySelector('[name="score"]').value);
    const rawHistory = row.querySelector('[name="history"]').value.trim();
    const history = rawHistory
      ? rawHistory.split(",").map((value) => Number(value.trim())).filter((value) => Number.isFinite(value))
      : [];
    return { name, score, history: [...history, score] };
  });
  const availability = Object.fromEntries(DAYS.map(([id]) => [id, Number($(`#availability-${id}`).value)]));
  return { subjects, availability, startMinutes: parseTime($("#start-time").value) };
}

function profileForForm(data) {
  return {
    subjects: data.subjects.map((subject) => ({
      name: subject.name,
      score: subject.score,
      history: subject.history.slice(0, -1).join(", ")
    })),
    availability: data.availability,
    startTime: `${String(Math.floor(data.startMinutes / 60)).padStart(2, "0")}:${String(data.startMinutes % 60).padStart(2, "0")}`
  };
}

function renderInsights(plan) {
  const priority = plan.subjects[0];
  const strength = plan.subjects.reduce((best, subject) => subject.predictedScore > best.predictedScore ? subject : best, plan.subjects[0]);
  $("#priority-name").textContent = priority.name;
  $("#priority-detail").textContent = `${priority.predictedScore}% estimated next score · ${priority.trendLabel}`;
  $("#total-time").textContent = formatMinutes(plan.schedule.totalMinutes);
  $("#total-detail").textContent = `Across ${plan.schedule.days.filter((day) => day.blocks.length).length} study days`;
  $("#strength-name").textContent = strength.name;
  $("#strength-detail").textContent = `${strength.predictedScore}% estimated next score · keep revising`;

  $("#insight-list").innerHTML = plan.subjects.map((subject) => {
    const allocation = plan.schedule.allocations.find((item) => item.name === subject.name);
    return `
      <div class="insight-row">
        <div class="subject-badge color-${subject.color}">${escapeHtml(initials(subject.name))}</div>
        <div class="subject-name"><strong>${escapeHtml(subject.name)}</strong><span>${subject.tier.label} · ${subject.predictedScore}% estimate</span></div>
        <div class="insight-reason">${escapeHtml(subject.reason)}.</div>
        <div class="suggestion"><strong>${formatMinutes(allocation?.targetMinutes || 0)} this week</strong>${subject.confidence}% trend confidence</div>
      </div>`;
  }).join("");
}

function renderPlan(plan) {
  $("#plan-caption").textContent = `Based on your availability and your latest assessment profile. Model: ${plan.model.name}.`;
  $("#schedule-total").textContent = formatMinutes(plan.schedule.totalMinutes);
  const max = Math.max(...plan.schedule.allocations.map((allocation) => allocation.targetMinutes), 1);
  $("#allocation-list").innerHTML = plan.schedule.allocations.map((allocation) => `
    <div class="allocation-item">
      <div class="allocation-label"><strong>${escapeHtml(allocation.name)}</strong><span>${formatMinutes(allocation.targetMinutes)} · ${escapeHtml(allocation.tier.label)}</span></div>
      <div class="allocation-track" aria-label="${escapeHtml(allocation.name)} receives ${formatMinutes(allocation.targetMinutes)}"><div class="allocation-fill fill-${allocation.color}" style="width:${Math.max(10, Math.round((allocation.targetMinutes / max) * 100))}%"></div></div>
    </div>`).join("");
  const noStudyTime = plan.schedule.totalMinutes < 30;
  $("#empty-schedule").hidden = !noStudyTime;
  $("#schedule-grid").hidden = noStudyTime;
  $("#schedule-grid").innerHTML = plan.schedule.days.map((day) => `
    <article class="day-column"><h4>${day.label.slice(0, 3)}</h4>${day.blocks.length
      ? day.blocks.map((block) => `<div class="study-block block-${block.color}" title="${escapeHtml(block.start)} to ${escapeHtml(block.end)}"><strong>${escapeHtml(block.subject)}</strong><span>${block.start} · ${block.duration}m</span></div>`).join("")
      : '<p class="no-block">Rest day</p>'}</article>`).join("");
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("visible"), 3500);
}

async function createPlan({ keepPosition = false } = {}) {
  const message = $("#form-message");
  message.textContent = "";
  const payload = getProfileFromForm();
  const button = $("#profile-form button[type=submit]");
  button.disabled = true;
  button.textContent = "Creating your plan…";
  try {
    const response = await fetch("/api/analyze", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || "We could not create your plan.");
    state.plan = body.plan;
    state.profile = profileForForm(payload);
    renderInsights(body.plan);
    renderPlan(body.plan);
    if (!keepPosition) $("#plan").scrollIntoView({ behavior: "smooth", block: "start" });
    showToast("Your timetable is ready. You can change scores or available time anytime.");
  } catch (error) {
    message.textContent = error.message;
  } finally {
    button.disabled = false;
    button.innerHTML = 'Create my study plan <span aria-hidden="true">→</span>';
  }
}

async function savePlan() {
  if (!state.plan) return showToast("Create a timetable before saving it.");
  const response = await fetch("/api/plans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(getProfileFromForm()) });
  const body = await response.json();
  if (!response.ok) return showToast(body.error || "We could not save this plan.");
  showToast("Plan saved locally in this demo workspace.");
}

$("#profile-form").addEventListener("submit", (event) => { event.preventDefault(); createPlan(); });
$("#add-subject").addEventListener("click", () => {
  const count = subjectFields.querySelectorAll(".subject-row").length;
  if (count >= 8) return showToast("A plan can include up to 8 subjects.");
  const current = getProfileFromForm();
  const formSubjects = profileForForm(current).subjects;
  formSubjects.push({ name: "", score: "", history: "" });
  renderSubjectFields(formSubjects);
  subjectFields.querySelector(".subject-row:last-child input")?.focus();
});
subjectFields.addEventListener("click", (event) => {
  if (!event.target.matches(".remove-subject")) return;
  const rows = [...subjectFields.querySelectorAll(".subject-row")];
  if (rows.length <= 2) return;
  event.target.closest(".subject-row").remove();
  rows.slice(0, -1).forEach((row, index) => row.dataset.subjectIndex = index);
});
$("#load-sample").addEventListener("click", () => {
  state.profile = structuredClone(SAMPLE_PROFILE);
  populateProfile(state.profile);
  createPlan({ keepPosition: true });
  showToast("Fictional sample scores loaded.");
});
$("#reset-demo").addEventListener("click", () => {
  state.profile = structuredClone(SAMPLE_PROFILE);
  populateProfile(state.profile);
  createPlan({ keepPosition: true });
  $("#profile").scrollIntoView({ behavior: "smooth", block: "start" });
});
$("#edit-profile").addEventListener("click", () => $("#profile").scrollIntoView({ behavior: "smooth", block: "start" }));
$("#regenerate").addEventListener("click", () => createPlan({ keepPosition: true }));
$("#save-plan").addEventListener("click", savePlan);
$(".mobile-menu").addEventListener("click", (event) => {
  const sidebar = $(".sidebar");
  const isOpen = sidebar.classList.toggle("menu-open");
  event.currentTarget.setAttribute("aria-expanded", String(isOpen));
  event.currentTarget.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});
document.querySelectorAll(".nav-link").forEach((link) => link.addEventListener("click", () => {
  $(".sidebar").classList.remove("menu-open");
  $(".mobile-menu").setAttribute("aria-expanded", "false");
  $(".mobile-menu").setAttribute("aria-label", "Open navigation");
}));

populateProfile(state.profile);
createPlan({ keepPosition: true });
