# StudyFlow

StudyFlow is a full-stack demonstration of a personalized study planner. Students enter subject scores and a realistic weekly availability. The app generates an explainable timetable that gives more time to subjects where the current performance profile suggests it may help most.

## Run it locally

```powershell
npm start
```

Open `http://localhost:3000` in a browser.

Run the algorithm tests with:

```powershell
npm test
```

## What the planner does

- Takes 2–8 subjects, a latest percentage, and optional earlier percentages.
- Fits a least-squares trend line to each subject’s score history.
- Creates a transparent priority score from predicted score, downward trend, and recent score variability.
- Allocates the selected weekly study time across every subject, keeping strong subjects in the revision loop.
- Produces 45-minute study blocks with short breaks and lets the student change scores or availability at any time.
- Saves an optional local demo history through the Node backend. `data/plans.json` stays out of source control.

## Responsible use

This is a planning aid rather than a grading, placement, or disciplinary system. The score estimate is only an input to time allocation. Students, teachers, and families should review and change the plan. The app accepts only subject names, assessment percentages, and availability, and it deliberately avoids demographic or sensitive student data.

## Stack

- Frontend: responsive HTML, CSS, and browser JavaScript
- Backend: Node.js built-in HTTP server with JSON endpoints
- Personalization: interpretable least-squares trend analysis and a documented priority formula
